/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package execeptions;

/**
 *
 * @author Luiz
 */
public class excessaoPersonalizada extends Exception{
    public excessaoPersonalizada(String mensagem){
        super(mensagem);
    }
}
