create database trabalhoconstantino;
ALTER USER 'root'@'localhost' IDENTIFIED BY '2004';
FLUSH PRIVILEGES;





























